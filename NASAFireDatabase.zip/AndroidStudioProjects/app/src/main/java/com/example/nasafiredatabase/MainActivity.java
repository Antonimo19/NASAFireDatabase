package com.example.nasafiredatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button launchViewFires;
    private Button launchAddFire;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        launchViewFires = (Button) findViewById(R.id.launch_view_fires);
        launchAddFire = (Button) findViewById(R.id.launch_add_fire);

        launchAddFire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addFire(v);
            }
        });
    }



    public void addFire(View view) {
        Intent i = new Intent(this, AddFireActivity.class);
        startActivity(i);
    }
}
