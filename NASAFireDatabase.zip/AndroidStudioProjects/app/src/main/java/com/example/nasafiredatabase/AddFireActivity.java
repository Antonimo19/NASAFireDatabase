package com.example.nasafiredatabase;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class AddFireActivity extends AppCompatActivity implements OnMapReadyCallback {

    private Button addButton;
    private Button callButton;
    private boolean add = false;
    private GoogleMap mMap;
    private ArrayList<LatLng> markerArray;
    private final Context context = this;
    private Spinner regionChooser;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_fire);
        markerArray = new ArrayList<LatLng>();
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        addButton = (Button) findViewById(R.id.add_fire);
        callButton = (Button) findViewById(R.id.call_emegercies);
        regionChooser = (Spinner) findViewById(R.id.change_region);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.continent, R.layout.spinner_item);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown);
        regionChooser.setAdapter(adapter);


        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (add) {
                    add = false;
                    addButton.setText("+");
                } else {
                    LayoutInflater inflater = getLayoutInflater();

                    View toastLayout = inflater.inflate(R.layout.add_fire_toast,
                            (ViewGroup) findViewById(R.id.toast_root_view));

                    Toast toast = new Toast(getApplicationContext());
                    toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, 300);
                    toast.setDuration(Toast.LENGTH_SHORT);
                    toast.setView(toastLayout);
                    toast.show();
                    add = true;
                    addButton.setText("-");
                }
            }
        });

        regionChooser.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                showFires(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                return;
            }
        });

        callButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                llamarAutoridades();
            }
        });

    }

    public void llamarAutoridades() {
        Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel://112"));
        startActivity(i);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onMapReady(final GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    Activity#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for Activity#requestPermissions for more details.
            return;
        }

        Location location = locationManager.getLastKnownLocation(locationManager.getBestProvider(criteria, false));

        LatLng ipos = new LatLng(location.getLatitude(), location.getLongitude());

        mMap.addMarker(new MarkerOptions().position(ipos).title(""));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(ipos, 10.0f));

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                if (add) {
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(latLng);

                    mMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
                    markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.blue_flame_marker2));

                    mMap.addMarker(markerOptions);
                    markerArray.add(latLng);

                    add = false;
                    addButton.setText("+");
                }
            }
        });

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(final Marker marker) {

                if (markerArray.contains(marker.getPosition())) {

                    AlertDialog.Builder alerDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(context, R.style.remove_fire_dialog));
                    alerDialogBuilder.setTitle(R.string.dialog_title)
                            .setMessage(R.string.dialog_text);
                    alerDialogBuilder.setCancelable(false)
                            .setPositiveButton(R.string.confirm_fire, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    marker.setIcon(BitmapDescriptorFactory.fromResource(R.drawable.flame_marker));
                                    markerArray.remove(marker.getPosition());
                                }
                            })
                            .setNegativeButton(R.string.remove_fire, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    marker.remove();
                                }
                            })
                            .setNeutralButton(R.string.cancel_fire, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog alertDialog = alerDialogBuilder.create();
                    alertDialog.show();
                }

                return true;
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void showFires(int position) {

        mMap.clear();

        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    Activity#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for Activity#requestPermissions for more details.
            return;
        }

        Location location = locationManager.getLastKnownLocation(locationManager.getBestProvider(criteria, false));

        LatLng ipos = new LatLng(location.getLatitude(), location.getLongitude());

        mMap.addMarker(new MarkerOptions().position(ipos).title(""));



        File f = null;
        FileReader fr = null;
        BufferedReader b = null;
        Double lat, lon;
        lat = 0.0;
        lon = 0.0;
        String[] parts;
        String mLine;
        String fileName;

        switch (position) {
            case 0:
                fileName = "fires_alaska.txt";
                break;
            case 1:
                fileName = "fires_canada.txt";
                break;
            case 2:
                fileName = "fires_cental_america.txt";
                break;
            case 3:
                fileName = "fires_sud_america.txt";
                break;
            case 4:
                fileName = "fires_europe.txt";
                break;
            case 5:
                fileName = "fires_rusia_asia.txt";
                break;
            case 6:
                fileName = "fires_sudeste_asia.txt";
                break;
            case 7:
                fileName = "sudeste_asiatico.txt";
                break;
            case 8:
                fileName = "fires_contiguos_africa.txt";
                break;
            case 9:
                fileName = "fires_norte_central_africa.txt";
                break;
            case 10:
                fileName = "fires_southern_africa.txt";
                break;
            case 11:
                fileName = "fires_australia.txt";
                break;
            default:
                fileName = "fires_europe.txt";
                break;
        }

        BufferedReader reader = null;
        try {
            reader = new BufferedReader(
                    new InputStreamReader(getAssets().open(fileName)));

            // do reading, usually loop until end of file reading

            reader.readLine();
            while ((mLine = reader.readLine()) != null) {


                parts = mLine.split(",");

                try {
                    lat = Double.parseDouble(parts[0]);
                    lon = Double.parseDouble(parts[1]);
                } catch (Exception e) {
                }

                MarkerOptions mk = new MarkerOptions();

                mk.position(new LatLng(lat, lon));
                mk.icon(BitmapDescriptorFactory.fromResource(R.drawable.flame_marker));

                mMap.addMarker(mk);


            }
        } catch (IOException e) {
            //log the exception
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    //log the exception
                }
            }
        }
    }
}